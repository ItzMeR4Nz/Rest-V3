package com.chevstrap.rbx.utility

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * Minimal root helper. Runs commands through `su -c`, so it needs no extra library.
 *
 * Output is decoded as ISO-8859-1 on purpose: one char == one byte, so String.length
 * is the exact byte count and can be used as a file offset. Callers that need UTF-8
 * must re-decode (ActivityWatcher already does this per line).
 */
object RootAccess {

    data class Result(val code: Int, val out: String, val err: String) {
        val ok: Boolean get() = code == 0
    }

    @Volatile
    private var rootConfirmed = false

    /** Single-quote a path for the shell. */
    fun quote(path: String): String = "'" + path.replace("'", "'\\''") + "'"

    fun run(command: String, timeoutSeconds: Long = 15): Result {
        return try {
            val process = ProcessBuilder("su", "-c", command).start()
            process.outputStream.close()

            var out = ""
            var err = ""
            val outThread = thread(isDaemon = true) { out = readAll(process.inputStream) }
            val errThread = thread(isDaemon = true) { err = readAll(process.errorStream) }

            if (!process.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                process.destroyForcibly()
                return Result(-2, "", "timeout")
            }

            outThread.join(2000)
            errThread.join(2000)
            Result(process.exitValue(), out, err)
        } catch (e: Exception) {
            Result(-1, "", e.message ?: e.javaClass.simpleName)
        }
    }

    private fun readAll(stream: InputStream): String {
        val buffer = ByteArrayOutputStream()
        stream.use { it.copyTo(buffer) }
        return buffer.toString(Charsets.ISO_8859_1.name())
    }

    /** True only if `su` works and actually gives uid 0. Positive result is cached. */
    fun isAvailable(): Boolean {
        if (rootConfirmed) return true
        val result = run("id -u", timeoutSeconds = 30) // 30s: user may still be answering the grant prompt
        val granted = result.ok && result.out.trim() == "0"
        if (granted) rootConfirmed = true
        return granted
    }

    fun isDirectory(path: String): Boolean = run("test -d ${quote(path)}").ok

    /**
     * Newest regular file in [dir] and its size in bytes, or null if there is none.
     * One `su` call, so polling stays cheap.
     */
    fun newestFile(dir: String): Pair<String, Long>? {
        val script = "cd ${quote(dir)} || exit 3; " +
                "for f in \$(ls -t); do " +
                "if [ -f \"\$f\" ]; then echo \"\$f\"; wc -c < \"\$f\"; break; fi; " +
                "done"
        val result = run(script)
        if (!result.ok) return null

        val lines = result.out.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size < 2) return null

        val size = lines[1].toLongOrNull() ?: return null
        return lines[0] to size
    }

    /** Bytes of [path] starting at zero-based [offset] (ISO-8859-1 decoded). Empty on failure. */
    fun readFrom(path: String, offset: Long): String {
        val result = run("tail -c +${offset + 1} ${quote(path)}")
        return if (result.ok) result.out else ""
    }
}
